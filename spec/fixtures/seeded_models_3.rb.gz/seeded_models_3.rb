SeededModel.seed do |s|
  s.id = 3
  s.title = "Baz"
end
